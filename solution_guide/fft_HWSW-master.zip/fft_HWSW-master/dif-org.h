#ifndef FFT_DFT_H
#define FFT_DFT_H

#include "dit-org.h"

int fix_dif_fft_org(fixed *fr, fixed *fi, int m, int inverse);

#endif //FFT_DFT_H
